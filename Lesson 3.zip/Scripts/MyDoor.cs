﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyDoor : MonoBehaviour
{
    public void Open()
    {
        Destroy(gameObject);
    }
    
}