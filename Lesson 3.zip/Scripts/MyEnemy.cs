﻿using UnityEngine;

public class MyEnemy : MonoBehaviour
{
    [SerializeField] private int _health;//здоровье

    public void Hurt(int damage)//метод урон(из здоровья вычетается урон и спрайт врага становится красным;если здоровья меньше 0, вызывается метод Die)
    {
        _health -= damage;

        var sprite = gameObject.GetComponent<SpriteRenderer>();
        sprite.color = Color.red;

        if(_health <= 0)
        {
            Die();
        }
        
    }
    public void Die()//метод Die (уничтожение объекта)
    {
        Destroy(gameObject);
    }
 
}
