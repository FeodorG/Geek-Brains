﻿using UnityEngine;

public class MyKey : MonoBehaviour
{

    private void OnTriggerEnter2D(Collider2D collision)//Если соприкосается с объектом Player создаёт копию префаба Enemy в точке SpawnPosition 
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Destroy(gameObject); 
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)//Вызывает метод урон из компонента MyDoor при соприкосновении с объектом Player
    {
        if (collision.gameObject.GetComponent("Player"))
        {
            var door = collision.gameObject.GetComponent<MyDoor>();
            door.Open();
        }
    }
}