﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyBullet : MonoBehaviour
{
    [SerializeField] private float _speed = 3; // скорость пули
    [SerializeField] private float _lifetime = 4;// время "жизни пули"
    private int _damage = 2;
    
    void Start()//Метод Start (начала полёта пули)
    {
        Destroy(gameObject, _lifetime);
    }

    public void Setdamage(int damage)//Метод Setdamage (настройка урона пули)
    {
        _damage = damage;
    }
  
    void Update()//движение пули
    {
        transform.position += CalculateSpeed(_speed);
    }

    private Vector3 CalculateSpeed(float dir)//направление пули
    {
        return transform.right * Time.deltaTime * dir;
    }
    private Vector3 CalculateSpeed2(float dir2)//направление пули
    {
        return transform.right * Time.deltaTime * dir2 * -1;
    }


    private void OnCollisionEnter2D(Collision2D collision)//Вызывает метод урон из компонента MyEnemy при соприкосновении с объектом Enemy
    {
        if(collision.gameObject.GetComponent("Enemy"))
        {
            var enemy = collision.gameObject.GetComponent<MyEnemy>();
            enemy.Hurt(_damage);
        }
    }



}
