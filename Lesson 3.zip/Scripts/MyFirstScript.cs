﻿using UnityEngine;

public class MyFirstScript : MonoBehaviour
{
    [SerializeField] private float _speed; //скорость
    [SerializeField] private GameObject _bullet;// объект пуля
    [SerializeField] private Transform _startBullet;//место старта полёта пули
    private float _curSpeed = 0;

    private Vector3 _dir = Vector3.zero;
    
   
    
   
    void Update()
    {
        _dir.x = Input.GetAxis("Horizontal") *_speed * Time.deltaTime;// передвижение по горизонтали(вперёд и назад)

        transform.position += _dir;

        _dir.y = Input.GetAxis("Jump") * _speed * Time.deltaTime; //прыжок, не понял как сделать так чтобы после прыжка спускался вниз (для этого нужно использовать кнопку x)


        if (Input.GetButtonDown("Fire1")) Fire();//стрельба
    }
    private void Fire()//метод Fire
    {
        Instantiate(_bullet, _startBullet.position, _startBullet.rotation);
    }

}
