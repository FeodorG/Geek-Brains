﻿using UnityEngine;

public class Turn : MonoBehaviour
{
    private bool faceRight = true;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        float moveX = Input.GetAxis("Horizontal");

        if (moveX > 0 && !faceRight)
            turn ();
        else if(moveX < 0 && faceRight)
            turn ();
    }

    void turn()
    {
        faceRight = !faceRight;
        transform.localScale = new Vector3(transform.localScale.x * -1, transform.localScale.y, transform.localScale.z);
    }
}
