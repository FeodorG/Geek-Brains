﻿using UnityEngine;
using System.Collections;

public class MyGbSpawner : MonoBehaviour
{   
    [SerializeField] private GameObject _enemy; //Враг
    [SerializeField] private Transform _spawnPosition;//Позиция спавна

    private void OnTriggerEnter2D(Collider2D collision)//Если соприкосается с объектом Player создаёт копию префаба Enemy в точке SpawnPosition 
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Instantiate(_enemy, _spawnPosition.position, _spawnPosition.rotation);
        }

    }

}
